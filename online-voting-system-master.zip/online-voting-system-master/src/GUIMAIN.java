import Menu.*;
import Voter.*;
import Admin.*;

public class GUIMAIN {

	public static void main (String[] arg )
	{
		StartFrame s = new StartFrame();
		s.setVisible(true);
	}
	
}